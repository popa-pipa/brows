const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

const SETTINGS_PATH = path.join(app.getPath('userData'), 'brows-settings.json');

const DEFAULT_SETTINGS = {
  searchEngine: 'google', // 'google' | 'yandex'
  homepage: 'brows://newtab',
  theme: {
    accent: '#ffb020',
    chromeBg: '#14161c',
    chromeBg2: '#1c1f28',
    tabActive: '#20232d',
    text: '#e7e7ea',
    textDim: '#8b8d98',
    radius: 10,
    density: 'comfortable', // 'comfortable' | 'compact'
    font: 'ui'
  },
  newtab: {
    bgType: 'gradient', // 'gradient' | 'solid' | 'image'
    bgValue: 'linear-gradient(135deg,#14161c,#1f2333 60%,#2a2140)',
    shortcuts: [
      { name: 'YouTube', url: 'https://youtube.com' },
      { name: 'GitHub', url: 'https://github.com' },
      { name: 'Yandex', url: 'https://ya.ru' },
      { name: 'Google', url: 'https://google.com' }
    ]
  }
};

function loadSettings() {
  try {
    const raw = fs.readFileSync(SETTINGS_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_SETTINGS, ...parsed,
      theme: { ...DEFAULT_SETTINGS.theme, ...(parsed.theme || {}) },
      newtab: { ...DEFAULT_SETTINGS.newtab, ...(parsed.newtab || {}) }
    };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

function saveSettings(settings) {
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2), 'utf-8');
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 760,
    minHeight: 480,
    frame: false, // собственная рамка/шапка — под визуальную кастомизацию
    backgroundColor: '#14161c',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true, // разрешаем <webview> для вкладок
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'browser.html'));
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ---- IPC: управление окном (своя шапка) ----
ipcMain.on('window:minimize', () => mainWindow?.minimize());
ipcMain.on('window:maximize', () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.on('window:close', () => mainWindow?.close());

// ---- IPC: настройки ----
ipcMain.handle('settings:get', () => loadSettings());
ipcMain.handle('settings:set', (_evt, settings) => {
  saveSettings(settings);
  return true;
});
ipcMain.handle('settings:reset', () => {
  saveSettings(DEFAULT_SETTINGS);
  return DEFAULT_SETTINGS;
});
