const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('browsAPI', {
  // управление окном
  minimize: () => ipcRenderer.send('window:minimize'),
  maximize: () => ipcRenderer.send('window:maximize'),
  close: () => ipcRenderer.send('window:close'),

  // настройки (сохраняются на диске, переживают перезапуск)
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (settings) => ipcRenderer.invoke('settings:set', settings),
  resetSettings: () => ipcRenderer.invoke('settings:reset')
});
