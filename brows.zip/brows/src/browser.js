(() => {
  'use strict';

  const SEARCH_ENGINES = {
    google: {
      label: 'Google',
      icon: 'G',
      buildUrl: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}`
    },
    yandex: {
      label: 'Яндекс',
      icon: 'Я',
      buildUrl: (q) => `https://ya.ru/search/?text=${encodeURIComponent(q)}`
    }
  };

  const FONT_STACKS = { ui: 'var(--font-ui)', mono: 'var(--font-mono)', round: 'var(--font-round)' };

  let settings = null;
  let tabs = [];        // { id, webview, title, url, loading }
  let activeTabId = null;
  let tabSeq = 0;

  const el = (id) => document.getElementById(id);
  const tabstrip = el('tabstrip');
  const webviewContainer = el('webview-container');
  const addressInput = el('address-input');
  const engineToggleBtn = el('engine-toggle');
  const engineIcon = el('engine-icon');
  const loadIndicator = el('load-indicator');

  // ---------- URL helpers ----------
  function looksLikeUrl(input) {
    const s = input.trim();
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) return true;         // has scheme
    if (/^localhost(:\d+)?(\/.*)?$/i.test(s)) return true;
    if (/^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(s)) return true; // IPv4
    // domain.tld with no spaces
    if (/^[^\s]+\.[a-z]{2,}(\/[^\s]*)?$/i.test(s) && !s.includes(' ')) return true;
    return false;
  }

  function normalizeUrl(input) {
    const s = input.trim();
    if (s === 'brows://newtab' || s === '') return newtabUrl();
    if (looksLikeUrl(s)) {
      if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) return 'https://' + s;
      return s;
    }
    return SEARCH_ENGINES[settings.searchEngine].buildUrl(s);
  }

  function newtabUrl() {
    return buildNewtabUrl();
  }

  function buildNewtabUrl() {
    const nt = settings.newtab;
    const params = new URLSearchParams({
      accent: settings.theme.accent,
      bgType: nt.bgType,
      bgValue: nt.bgValue,
      engine: settings.searchEngine,
      shortcuts: JSON.stringify(nt.shortcuts)
    });
    return `newtab.html?${params.toString()}`;
  }

  function resolveHomepage() {
    return normalizeUrl(settings.homepage || 'brows://newtab');
  }

  // ---------- Theme ----------
  function applyTheme() {
    const t = settings.theme;
    const root = document.documentElement.style;
    root.setProperty('--accent', t.accent);
    root.setProperty('--chrome-bg', t.chromeBg);
    root.setProperty('--chrome-bg-2', t.chromeBg2);
    root.setProperty('--tab-active', t.tabActive);
    root.setProperty('--radius', t.radius + 'px');
    root.setProperty('--font-current', FONT_STACKS[t.font] || FONT_STACKS.ui);

    if (t.density === 'compact') {
      root.setProperty('--toolbar-h', '38px');
      root.setProperty('--tab-h', '28px');
    } else {
      root.setProperty('--toolbar-h', '46px');
      root.setProperty('--tab-h', '34px');
    }

    engineIcon.textContent = SEARCH_ENGINES[settings.searchEngine].icon;
  }

  function persistSettings() {
    window.browsAPI.setSettings(settings);
  }

  // ---------- Tabs ----------
  function createTab(rawUrl, activate = true) {
    const id = 'tab-' + (++tabSeq);
    const url = normalizeUrl(rawUrl || 'brows://newtab');

    const webview = document.createElement('webview');
    webview.setAttribute('src', url);
    webview.setAttribute('allowpopups', '');
    webviewContainer.appendChild(webview);

    const tabEl = document.createElement('div');
    tabEl.className = 'tab';
    tabEl.dataset.id = id;
    tabEl.innerHTML = `
      <span class="tab-favicon"></span>
      <span class="tab-title">Новая вкладка</span>
      <button class="tab-close" title="Закрыть">&#10005;</button>
    `;
    tabstrip.appendChild(tabEl);

    const tab = { id, webview, tabEl, title: 'Новая вкладка', url, loading: true, canBack: false, canForward: false };
    tabs.push(tab);

    tabEl.addEventListener('click', (e) => {
      if (e.target.closest('.tab-close')) return;
      switchTab(id);
    });
    tabEl.querySelector('.tab-close').addEventListener('click', (e) => {
      e.stopPropagation();
      closeTab(id);
    });

    webview.addEventListener('page-title-updated', (e) => {
      tab.title = e.title || tab.title;
      tabEl.querySelector('.tab-title').textContent = tab.title;
    });
    webview.addEventListener('page-favicon-updated', (e) => {
      if (e.favicons && e.favicons[0]) {
        tabEl.querySelector('.tab-favicon').style.background = `center/contain no-repeat url(${e.favicons[0]})`;
      }
    });
    webview.addEventListener('did-start-loading', () => {
      tab.loading = true;
      if (tab.id === activeTabId) updateLoadIndicator();
    });
    webview.addEventListener('did-stop-loading', () => {
      tab.loading = false;
      tab.canBack = webview.canGoBack();
      tab.canForward = webview.canGoForward();
      if (tab.id === activeTabId) { updateLoadIndicator(); updateNavButtons(); }
    });
    webview.addEventListener('did-navigate', (e) => onNavigate(tab, e.url));
    webview.addEventListener('did-navigate-in-page', (e) => onNavigate(tab, e.url));
    webview.addEventListener('new-window', (e) => {
      // открываем во внутренней новой вкладке вместо системного окна
      createTab(e.url, true);
    });

    if (activate) switchTab(id);
    return tab;
  }

  function onNavigate(tab, url) {
    tab.url = url;
    if (tab.id === activeTabId) {
      addressInput.value = url.includes('newtab.html') ? '' : url;
    }
  }

  function switchTab(id) {
    activeTabId = id;
    tabs.forEach((t) => {
      const isActive = t.id === id;
      t.webview.classList.toggle('active', isActive);
      t.tabEl.classList.toggle('active', isActive);
    });
    const tab = getActiveTab();
    if (tab) {
      addressInput.value = tab.url.includes('newtab.html') ? '' : tab.url;
      updateLoadIndicator();
      updateNavButtons();
    }
  }

  function closeTab(id) {
    const idx = tabs.findIndex((t) => t.id === id);
    if (idx === -1) return;
    const [tab] = tabs.splice(idx, 1);
    tab.webview.remove();
    tab.tabEl.remove();

    if (tabs.length === 0) {
      createTab('brows://newtab');
      return;
    }
    if (activeTabId === id) {
      const next = tabs[idx] || tabs[idx - 1] || tabs[0];
      switchTab(next.id);
    }
  }

  function getActiveTab() {
    return tabs.find((t) => t.id === activeTabId);
  }

  function updateLoadIndicator() {
    const tab = getActiveTab();
    loadIndicator.classList.toggle('hidden', !tab || !tab.loading);
    loadIndicator.classList.toggle('spin', !!(tab && tab.loading));
  }

  function updateNavButtons() {
    const tab = getActiveTab();
    el('btn-back').disabled = !tab || !tab.canBack;
    el('btn-forward').disabled = !tab || !tab.canForward;
  }

  // ---------- Navigation controls ----------
  el('btn-back').addEventListener('click', () => getActiveTab()?.webview.goBack());
  el('btn-forward').addEventListener('click', () => getActiveTab()?.webview.goForward());
  el('btn-reload').addEventListener('click', () => getActiveTab()?.webview.reload());
  el('btn-home').addEventListener('click', () => navigateActive(resolveHomepage()));
  el('tab-add').addEventListener('click', () => createTab('brows://newtab'));

  function navigateActive(url) {
    const tab = getActiveTab();
    if (!tab) return;
    tab.webview.src = url;
  }

  addressInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const target = normalizeUrl(addressInput.value);
      navigateActive(target);
      addressInput.blur();
    }
  });

  engineToggleBtn.addEventListener('click', () => {
    settings.searchEngine = settings.searchEngine === 'google' ? 'yandex' : 'google';
    applyTheme();
    syncSettingsUI();
    persistSettings();
    pushNewtabSettingsToAllTabs();
  });

  // ---------- Window controls ----------
  el('win-min').addEventListener('click', () => window.browsAPI.minimize());
  el('win-max').addEventListener('click', () => window.browsAPI.maximize());
  el('win-close').addEventListener('click', () => window.browsAPI.close());

  // ---------- Keyboard shortcuts ----------
  window.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 't') { e.preventDefault(); createTab('brows://newtab'); }
    if (mod && e.key.toLowerCase() === 'w') { e.preventDefault(); if (activeTabId) closeTab(activeTabId); }
    if (mod && e.key.toLowerCase() === 'l') { e.preventDefault(); addressInput.focus(); addressInput.select(); }
  });

  // ---------- Settings panel ----------
  const panel = el('settings-panel');
  el('btn-settings').addEventListener('click', () => panel.classList.toggle('hidden'));
  el('settings-close').addEventListener('click', () => panel.classList.add('hidden'));

  function wireSeg(containerId, key, path) {
    const container = el(containerId);
    container.querySelectorAll('.seg-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.seg-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        setDeep(path, btn.dataset[key]);
        applyTheme();
        persistSettings();
      });
    });
  }

  function setDeep(path, value) {
    // path e.g. "theme.radius" or "searchEngine"
    const parts = path.split('.');
    let obj = settings;
    for (let i = 0; i < parts.length - 1; i++) obj = obj[parts[i]];
    obj[parts[parts.length - 1]] = value;
  }

  function getDeep(path) {
    const parts = path.split('.');
    let obj = settings;
    for (const p of parts) obj = obj[p];
    return obj;
  }

  wireSeg('engine-picker', 'engine', 'searchEngine');
  el('engine-picker').addEventListener('click', (e) => {
    if (e.target.closest('.seg-btn')) { applyTheme(); pushNewtabSettingsToAllTabs(); }
  });
  wireSeg('density-picker', 'density', 'theme.density');
  wireSeg('font-picker', 'font', 'theme.font');
  wireSeg('newtab-bgtype-picker', 'bgtype', 'newtab.bgType');
  el('newtab-bgtype-picker').addEventListener('click', (e) => {
    if (e.target.closest('.seg-btn')) pushNewtabSettingsToAllTabs();
  });

  el('homepage-input').addEventListener('change', (e) => {
    settings.homepage = e.target.value.trim() || 'brows://newtab';
    persistSettings();
  });

  el('accent-swatches').addEventListener('click', (e) => {
    const btn = e.target.closest('.swatch');
    if (!btn) return;
    settings.theme.accent = btn.dataset.color;
    el('accent-custom').value = btn.dataset.color;
    document.querySelectorAll('#accent-swatches .swatch').forEach((s) => s.classList.remove('active'));
    btn.classList.add('active');
    applyTheme(); persistSettings(); pushNewtabSettingsToAllTabs();
  });
  el('accent-custom').addEventListener('input', (e) => {
    settings.theme.accent = e.target.value;
    applyTheme(); persistSettings(); pushNewtabSettingsToAllTabs();
  });

  el('chromebg-input').addEventListener('input', (e) => {
    settings.theme.chromeBg = e.target.value;
    settings.theme.chromeBg2 = shade(e.target.value, 8);
    applyTheme(); persistSettings();
  });
  el('tabactive-input').addEventListener('input', (e) => {
    settings.theme.tabActive = e.target.value;
    applyTheme(); persistSettings();
  });

  el('radius-input').addEventListener('input', (e) => {
    settings.theme.radius = Number(e.target.value);
    el('radius-val').textContent = e.target.value;
    applyTheme(); persistSettings();
  });

  el('newtab-bgvalue-input').addEventListener('change', (e) => {
    settings.newtab.bgValue = e.target.value.trim();
    persistSettings();
    pushNewtabSettingsToAllTabs();
  });

  el('settings-reset').addEventListener('click', async () => {
    settings = await window.browsAPI.resetSettings();
    applyTheme();
    syncSettingsUI();
    pushNewtabSettingsToAllTabs();
  });

  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    let r = Math.min(255, Math.max(0, (n >> 16) + amt));
    let g = Math.min(255, Math.max(0, ((n >> 8) & 0xff) + amt));
    let b = Math.min(255, Math.max(0, (n & 0xff) + amt));
    return '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
  }

  function syncSettingsUI() {
    document.querySelectorAll('#engine-picker .seg-btn').forEach((b) =>
      b.classList.toggle('active', b.dataset.engine === settings.searchEngine));
    document.querySelectorAll('#density-picker .seg-btn').forEach((b) =>
      b.classList.toggle('active', b.dataset.density === settings.theme.density));
    document.querySelectorAll('#font-picker .seg-btn').forEach((b) =>
      b.classList.toggle('active', b.dataset.font === settings.theme.font));
    document.querySelectorAll('#newtab-bgtype-picker .seg-btn').forEach((b) =>
      b.classList.toggle('active', b.dataset.bgtype === settings.newtab.bgType));
    document.querySelectorAll('#accent-swatches .swatch').forEach((b) =>
      b.classList.toggle('active', b.dataset.color === settings.theme.accent));

    el('homepage-input').value = settings.homepage;
    el('accent-custom').value = settings.theme.accent;
    el('chromebg-input').value = settings.theme.chromeBg;
    el('tabactive-input').value = settings.theme.tabActive;
    el('radius-input').value = settings.theme.radius;
    el('radius-val').textContent = settings.theme.radius;
    el('newtab-bgvalue-input').value = settings.newtab.bgValue;
  }

  function pushNewtabSettingsToAllTabs() {
    // страница новой вкладки читает настройки из query-параметров URL,
    // поэтому просто пересобираем адрес и мягко обновляем открытые вкладки
    const url = buildNewtabUrl();
    tabs.forEach((t) => {
      if (t.webview.getURL && t.webview.getURL().includes('newtab.html')) {
        t.webview.src = url;
      }
    });
  }

  // ---------- Init ----------
  async function init() {
    settings = await window.browsAPI.getSettings();
    applyTheme();
    syncSettingsUI();
    createTab(resolveHomepage());
  }

  init();
})();
